# InstallLock

Device-owner app for installment phones.

- Customer screen ("Meri Qistein"): plan, paid / remaining installments, next due date, shop call button.
- Reminder notification once a day when an installment is due within 2 days (or late).
- Server (Supabase) decides lock / unlock / release through `rpc/device_status`.
- Blocks factory reset and uninstall (real mode). Emergency calls always work.
- QR enrollment carries: server URL, publishable key, sale id, device token, test_mode flag.

## Test mode
QR made with "TEST mode" ticked: factory reset is NOT blocked, and the app shows a
"TEST khatam" button that removes the device-owner role. Use this on a spare phone first.

## Build
GitHub Actions -> "Build APK" workflow (needs the 4 signing secrets). Output: Releases -> installlock.apk
