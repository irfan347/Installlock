# InstallLock (starter)

Device-owner app for installment phones: blocks factory reset and uninstall,
locks the phone when the server says so, always allows emergency calls,
and releases itself when the customer finishes paying.

## Build
Put `app/` in an Android Studio project (Kotlin, Gradle). Build, sign with your
release key, host the APK on an HTTPS direct link.

## Test on your own phone first (debug build)
1. Factory reset the test phone, skip Google account setup.
2. `adb shell dpm set-device-owner com.example.installlock/.AdminReceiver`
3. Debug builds do NOT block factory reset/debugging, and are testOnly, so you can undo with
   `adb shell dpm remove-active-admin com.example.installlock/.AdminReceiver`.

## Real enrollment (QR)
1. `apksigner verify --print-certs installlock.apk` -> copy the SHA-256 fingerprint.
2. `python tools/make_qr.py ...` (see file header) -> one QR per customer.
3. New/reset phone: on the Welcome screen tap 6 times, scan the QR.
   Phone downloads the app, makes it device owner, and applies the policies.

## Server contract
`GET {server}/api/device/status?customer_id=...`  with `Authorization: Bearer <token>`
```
{"locked": false, "message": "optional text", "due_date_ms": 1760000000000, "release": false}
```
- `locked: true`  -> phone locks. `false` -> unlocks.
- `release: true` -> all restrictions removed and the app removes itself (final payment done).
- If the server is unreachable, the phone locks locally once `due_date_ms` passes.

## Must-do before real customers
- Written agreement that clearly explains the lock, signed by the customer.
- Keep emergency calls working (already built in). Never wipe customer data.
- Release the device when the last installment is paid.
- Test on 5-6 brands (Samsung, Infinix, Tecno, Oppo, Vivo, Xiaomi): some skins
  restrict starting activities from the background, so verify lock works with the screen off.
- This code has not been compiled or run on real hardware; treat it as a starting point.
