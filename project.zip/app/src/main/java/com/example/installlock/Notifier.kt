package com.example.installlock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

object Notifier {
    private const val CHANNEL = "installments"

    /** Once a day (after 9am Pakistan time): reminder when the next installment is due in 2 days or less, or late. */
    fun maybeNotify(c: Context, j: JSONObject) {
        val nextDue = j.optString("next_due_date", "")
        if (nextDue.isEmpty() || nextDue == "null") return

        val tz = TimeZone.getTimeZone("Asia/Karachi")
        val now = Calendar.getInstance(tz)
        if (now.get(Calendar.HOUR_OF_DAY) < 9) return

        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }
        val today = fmt.format(now.time)
        val p = c.getSharedPreferences("state", Context.MODE_PRIVATE)
        if (p.getString("notif_day", "") == today) return

        val due = fmt.parse(nextDue) ?: return
        val base = fmt.parse(today) ?: return
        val days = ((due.time - base.time) / 86_400_000L).toInt()
        val amount = "Rs. " + String.format(Locale.US, "%,.0f", j.optDouble("next_amount", 0.0))

        val text = when {
            days < 0 -> "Aap ki qist ${-days} din se late hai ($amount). Phone lock ho sakta hai, fauran ada karein."
            days == 0 -> "Aaj aap ki qist ada karne ka din hai: $amount"
            days <= 2 -> "Aap ki qist $days din mein ada honi hai: $amount"
            else -> return
        }
        post(c, text)
        p.edit().putString("notif_day", today).apply()
    }

    private fun post(c: Context, text: String) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Qist ki yaad-dehani", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Qist ki yaad-dehani")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(1001, n)
        } catch (e: Exception) { }
    }
}
