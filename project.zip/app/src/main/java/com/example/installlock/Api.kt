package com.example.installlock

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Api {
    /**
     * Asks Supabase for this phone's status. Applies lock / unlock / release,
     * caches the plan for the customer screen, and shows the reminder notification.
     * Returns true if the server answered.
     */
    fun refresh(c: Context): Boolean {
        val cfg = Policy.config(c)
        if (cfg.server.isEmpty() || cfg.saleId.isEmpty()) return false
        try {
            val con = URL("${cfg.server}/rest/v1/rpc/device_status").openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.doOutput = true
            con.setRequestProperty("apikey", cfg.anonKey)
            con.setRequestProperty("Content-Type", "application/json")
            con.connectTimeout = 10_000
            con.readTimeout = 10_000
            val body = JSONObject().put("p_sale", cfg.saleId).put("p_token", cfg.token).toString()
            con.outputStream.use { it.write(body.toByteArray()) }
            if (con.responseCode != 200) return false
            val j = JSONObject(con.inputStream.bufferedReader().readText())
            if (j.has("error")) return false

            Policy.setInfo(c, j.toString())
            Policy.setDue(c, j.optLong("due_date_ms", 0L))
            when {
                j.optBoolean("release") -> { Policy.release(c); return true }
                j.optBoolean("locked") -> Policy.lock(c, j.optString("message", ""))
                else -> Policy.unlock(c)
            }
            Notifier.maybeNotify(c, j)
            return true
        } catch (e: Exception) {
            return false
        }
    }
}
