package com.example.installlock

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Every ~15 min: ask the server whether this phone should be locked.
 * Expected JSON: {"locked":bool, "message":"...", "due_date_ms":long, "release":bool}
 */
class StatusWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val c = applicationContext
        if (!Policy.isOwner(c)) return Result.success()
        Policy.applyBase(c)

        try {
            val cfg = Policy.config(c)
            if (cfg.server.isNotEmpty()) {
                val id = URLEncoder.encode(cfg.customerId, "UTF-8")
                val con = URL("${cfg.server}/api/device/status?customer_id=$id")
                    .openConnection() as HttpURLConnection
                con.setRequestProperty("Authorization", "Bearer ${cfg.token}")
                con.connectTimeout = 10_000
                con.readTimeout = 10_000
                if (con.responseCode == 200) {
                    val j = JSONObject(con.inputStream.bufferedReader().readText())
                    Policy.setDue(c, j.optLong("due_date_ms", 0L))
                    when {
                        j.optBoolean("release") -> { Policy.release(c); return Result.success() }
                        j.optBoolean("locked") -> Policy.lock(c, j.optString("message", ""))
                        else -> Policy.unlock(c)
                    }
                    return Result.success()
                }
            }
        } catch (e: Exception) {
            // Offline or server down: fall through to the local due-date fallback.
        }

        val due = Policy.dueMs(c)
        if (!Policy.isLocked(c) && due > 0 && due < System.currentTimeMillis()) {
            Policy.lock(c, null)
        } else if (Policy.isLocked(c)) {
            Policy.showLockScreen(c)
        }
        return Result.success()
    }

    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<StatusWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(c)
                .enqueueUniquePeriodicWork("status", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
