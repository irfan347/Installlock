package com.example.installlock

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Every ~15 min: refresh status from the server; offline fallback locks locally once the due date has passed. */
class StatusWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val c = applicationContext
        if (!Policy.isOwner(c)) return Result.success()
        Policy.applyBase(c)

        val answered = Api.refresh(c)
        if (!Policy.isOwner(c)) return Result.success() // released

        if (!answered) {
            val due = Policy.dueMs(c)
            if (!Policy.isLocked(c) && due > 0 && due < System.currentTimeMillis()) {
                Policy.lock(c, null)
            }
        }
        if (Policy.isLocked(c)) Policy.showLockScreen(c)
        return Result.success()
    }

    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<StatusWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(c)
                .enqueueUniquePeriodicWork("status", ExistingPeriodicWorkPolicy.UPDATE, req)
        }
    }
}
