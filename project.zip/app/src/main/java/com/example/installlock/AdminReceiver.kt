package com.example.installlock

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle

class AdminReceiver : DeviceAdminReceiver() {

    // Runs once, right after QR enrollment finishes.
    @Suppress("DEPRECATION")
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val x = intent.getParcelableExtra<PersistableBundle>(
            DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE
        )
        val test = x?.getBoolean("test_mode", false) == true || x?.getString("test_mode") == "true"
        Policy.saveConfig(
            context,
            server = x?.getString("server"),
            anonKey = x?.getString("anon_key"),
            saleId = x?.getString("sale_id"),
            token = x?.getString("token"),
            test = test
        )
        Policy.applyBase(context)
        StatusWorker.schedule(context)
    }
}
