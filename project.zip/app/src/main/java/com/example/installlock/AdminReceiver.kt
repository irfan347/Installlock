package com.example.installlock

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.os.PersistableBundle

class AdminReceiver : DeviceAdminReceiver() {

    // Runs once, right after QR enrollment finishes.
    @Suppress("DEPRECATION")
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val extras = intent.getParcelableExtra<PersistableBundle>(
            DevicePolicyManager.EXTRA_PROVISIONING_ADMIN_EXTRAS_BUNDLE
        )
        Policy.saveConfig(
            context,
            server = extras?.getString("server"),
            customerId = extras?.getString("customer_id"),
            token = extras?.getString("token")
        )
        Policy.applyBase(context)
        StatusWorker.schedule(context)
    }
}
