package com.example.installlock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!Policy.isOwner(context)) return
        Policy.applyBase(context)
        StatusWorker.schedule(context)
        if (Policy.isLocked(context)) Policy.showLockScreen(context)
    }
}
