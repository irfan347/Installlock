package com.example.installlock

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class LockActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!Policy.isLocked(this@LockActivity)) { release(); return }
            handler.postDelayed(this, 3000)
        }
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        )

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "Phone lock hai"
            textSize = 26f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = Policy.message(this@LockActivity)
            textSize = 18f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        })
        // Emergency calls must always work.
        root.addView(Button(this).apply {
            text = "Emergency call"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:1122")))
            }
        })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Policy.isOwner(this)) {
            if (Build.VERSION.SDK_INT >= 28) {
                Policy.dpm(this).setLockTaskFeatures(Policy.admin(this), 0)
            }
            try { startLockTask() } catch (e: Exception) { }
        }
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Back is disabled while locked")
    override fun onBackPressed() { /* ignore */ }

    private fun release() {
        try { stopLockTask() } catch (e: Exception) { }
        finish()
    }
}
