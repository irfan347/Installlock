package com.example.installlock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import android.telecom.TelecomManager

data class Config(val server: String, val anonKey: String, val saleId: String, val token: String)

object Policy {
    private fun prefs(c: Context) = c.getSharedPreferences("state", Context.MODE_PRIVATE)
    fun dpm(c: Context): DevicePolicyManager = c.getSystemService(DevicePolicyManager::class.java)
    fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    fun isOwner(c: Context) = dpm(c).isDeviceOwnerApp(c.packageName)

    /** Test mode: factory reset and debugging are NOT blocked, so a spare phone can always be recovered. */
    fun isTestMode(c: Context) = BuildConfig.DEBUG || prefs(c).getBoolean("test", false)

    private val ALL_RESTRICTIONS = listOf(
        UserManager.DISALLOW_SAFE_BOOT,
        UserManager.DISALLOW_ADD_USER,
        UserManager.DISALLOW_FACTORY_RESET,
        UserManager.DISALLOW_DEBUGGING_FEATURES
    )

    private fun activeRestrictions(c: Context): List<String> =
        if (isTestMode(c)) listOf(UserManager.DISALLOW_SAFE_BOOT, UserManager.DISALLOW_ADD_USER)
        else ALL_RESTRICTIONS

    fun saveConfig(c: Context, server: String?, anonKey: String?, saleId: String?, token: String?, test: Boolean) {
        prefs(c).edit()
            .putString("server", server ?: "")
            .putString("anon", anonKey ?: "")
            .putString("sale", saleId ?: "")
            .putString("token", token ?: "")
            .putBoolean("test", test)
            .apply()
    }

    fun config(c: Context): Config {
        val p = prefs(c)
        return Config(
            p.getString("server", "")!!, p.getString("anon", "")!!,
            p.getString("sale", "")!!, p.getString("token", "")!!
        )
    }

    /** Factory-reset block (real mode), uninstall block, lock-task whitelist, notification permission. */
    fun applyBase(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        ALL_RESTRICTIONS.forEach { d.clearUserRestriction(a, it) }
        activeRestrictions(c).forEach { d.addUserRestriction(a, it) }
        d.setUninstallBlocked(a, c.packageName, true)
        val dialer = c.getSystemService(TelecomManager::class.java).defaultDialerPackage
        d.setLockTaskPackages(a, listOfNotNull(c.packageName, dialer).toTypedArray())
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                d.setPermissionGrantState(
                    a, c.packageName, Manifest.permission.POST_NOTIFICATIONS,
                    DevicePolicyManager.PERMISSION_GRANT_STATE_GRANTED
                )
            } catch (e: Exception) { }
        }
    }

    fun isLocked(c: Context) = prefs(c).getBoolean("locked", false)
    fun message(c: Context) = prefs(c).getString("msg", null)
        ?: "Qist ada nahi hui. Barah-e-karam dukaan se rabta karein."
    fun dueMs(c: Context) = prefs(c).getLong("due", 0L)
    fun setDue(c: Context, v: Long) = prefs(c).edit().putLong("due", v).apply()

    fun setInfo(c: Context, json: String) =
        prefs(c).edit().putString("info", json).putLong("sync", System.currentTimeMillis()).apply()
    fun info(c: Context): String? = prefs(c).getString("info", null)
    fun lastSync(c: Context): Long = prefs(c).getLong("sync", 0L)

    fun lock(c: Context, msg: String?) {
        val e = prefs(c).edit()
        e.putBoolean("locked", true)
        if (!msg.isNullOrBlank()) e.putString("msg", msg)
        e.apply()
        showLockScreen(c)
    }

    fun unlock(c: Context) {
        prefs(c).edit().putBoolean("locked", false).apply()
    }

    fun showLockScreen(c: Context) {
        try {
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            dpm(c).lockNow()
        }
    }

    /** All installments paid (or test finished): remove every restriction and the device-owner role. */
    fun release(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        ALL_RESTRICTIONS.forEach { d.clearUserRestriction(a, it) }
        d.setUninstallBlocked(a, c.packageName, false)
        prefs(c).edit().clear().apply()
        d.clearDeviceOwnerApp(c.packageName)
    }
}
