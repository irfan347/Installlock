package com.example.installlock

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.UserManager
import android.telecom.TelecomManager

data class Config(val server: String, val customerId: String, val token: String)

object Policy {
    private fun prefs(c: Context) = c.getSharedPreferences("state", Context.MODE_PRIVATE)
    fun dpm(c: Context): DevicePolicyManager = c.getSystemService(DevicePolicyManager::class.java)
    fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)
    fun isOwner(c: Context) = dpm(c).isDeviceOwnerApp(c.packageName)

    // In debug builds we skip these two so a test phone can always be recovered.
    private fun restrictions(): List<String> {
        val r = mutableListOf(UserManager.DISALLOW_SAFE_BOOT, UserManager.DISALLOW_ADD_USER)
        if (!BuildConfig.DEBUG) {
            r += UserManager.DISALLOW_FACTORY_RESET
            r += UserManager.DISALLOW_DEBUGGING_FEATURES
        }
        return r
    }

    fun saveConfig(c: Context, server: String?, customerId: String?, token: String?) {
        prefs(c).edit()
            .putString("server", server ?: "")
            .putString("customer", customerId ?: "")
            .putString("token", token ?: "")
            .apply()
    }

    fun config(c: Context): Config {
        val p = prefs(c)
        return Config(p.getString("server", "")!!, p.getString("customer", "")!!, p.getString("token", "")!!)
    }

    /** Factory-reset block, uninstall block, lock-task whitelist. Safe to call repeatedly. */
    fun applyBase(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        restrictions().forEach { d.addUserRestriction(a, it) }
        d.setUninstallBlocked(a, c.packageName, true)
        val dialer = c.getSystemService(TelecomManager::class.java).defaultDialerPackage
        d.setLockTaskPackages(a, listOfNotNull(c.packageName, dialer).toTypedArray())
    }

    fun isLocked(c: Context) = prefs(c).getBoolean("locked", false)
    fun message(c: Context) = prefs(c).getString("msg", null)
        ?: "Qist ada nahi hui. Barah-e-karam dukaan se rabta karein."
    fun dueMs(c: Context) = prefs(c).getLong("due", 0L)
    fun setDue(c: Context, v: Long) = prefs(c).edit().putLong("due", v).apply()

    fun lock(c: Context, msg: String?) {
        val e = prefs(c).edit()
        e.putBoolean("locked", true)
        if (!msg.isNullOrBlank()) e.putString("msg", msg)
        e.apply()
        showLockScreen(c)
    }

    fun unlock(c: Context) {
        prefs(c).edit().putBoolean("locked", false).apply()
    }

    fun showLockScreen(c: Context) {
        try {
            c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // Background start can be refused on some builds; at least lock the screen.
            dpm(c).lockNow()
        }
    }

    /** Called when the customer has paid everything: removes all restrictions and the DPC itself. */
    fun release(c: Context) {
        if (!isOwner(c)) return
        val d = dpm(c)
        val a = admin(c)
        restrictions().forEach { d.clearUserRestriction(a, it) }
        d.setUninstallBlocked(a, c.packageName, false)
        prefs(c).edit().clear().apply()
        d.clearDeviceOwnerApp(c.packageName)
    }
}
