package com.example.installlock

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Customer screen: plan, paid / remaining installments, next due date, shop contact. */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
            setBackgroundColor(Color.WHITE)
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        render(null)
        refreshInBackground()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rs(d: Double) = "Rs. " + String.format(Locale.US, "%,.0f", if (d.isNaN()) 0.0 else d)

    private fun tv(text: String, size: Float = 16f, bold: Boolean = false, color: Int = Color.BLACK) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun refreshInBackground() {
        Thread {
            val ok = Api.refresh(applicationContext)
            runOnUiThread { if (!isFinishing) render(ok) }
        }.start()
    }

    private fun render(synced: Boolean?) {
        root.removeAllViews()
        root.addView(tv("Meri Qistein", 26f, true, Color.parseColor("#0f766e")))

        val raw = Policy.info(this)
        if (raw == null) {
            root.addView(tv("Maloomat load ho rahi hain. Internet on karke Refresh dabayein.", 16f, color = Color.DKGRAY))
        } else {
            val j = JSONObject(raw)
            val total = j.optInt("total_installments")
            val paid = j.optInt("paid_installments")
            root.addView(tv("Assalam o Alaikum, ${j.optString("customer_name")}", 18f, true))
            root.addView(tv("Mobile: ${j.optString("device_model")}"))
            root.addView(tv("Qeemat: ${rs(j.optDouble("price"))}    Advance: ${rs(j.optDouble("advance"))}"))
            root.addView(tv("Ada ho chuki: $paid / $total qistein", 20f, true))
            root.addView(tv("Baqi rakam: ${rs(j.optDouble("remaining_amount"))}", 18f, true, Color.parseColor("#b91c1c")))

            val nd = j.optString("next_due_date", "")
            if (nd.isNotEmpty() && nd != "null") {
                root.addView(tv("Agli qist: $nd  (${rs(j.optDouble("next_amount"))})", 17f, true))
            } else if (total > 0) {
                root.addView(tv("Saari qistein ada ho gayi. Shukriya!", 18f, true, Color.parseColor("#166534")))
            }

            val list = j.optJSONArray("installments")
            if (list != null && list.length() > 0) {
                root.addView(tv("Qiston ki list", 18f, true).apply { setPadding(0, dp(16), 0, dp(4)) })
                for (i in 0 until list.length()) {
                    val it = list.getJSONObject(i)
                    val st = when (it.optString("status")) {
                        "paid" -> "Ada ho gayi"
                        "submitted" -> "TID jama (tasdeeq baqi)"
                        else -> "Baqi"
                    }
                    val color = when (it.optString("status")) {
                        "paid" -> Color.parseColor("#166534")
                        "submitted" -> Color.parseColor("#b45309")
                        else -> Color.BLACK
                    }
                    root.addView(tv("#${it.optInt("seq")}   ${it.optString("due_date")}   ${rs(it.optDouble("amount"))}   $st", 15f, color = color))
                }
            }

            val shop = j.optString("shop_name", "")
            val phone = j.optString("shop_phone", "")
            if (shop.isNotEmpty() && shop != "null") {
                root.addView(tv("Dukaan: $shop", 16f, true).apply { setPadding(0, dp(16), 0, dp(4)) })
                if (phone.isNotEmpty() && phone != "null") {
                    root.addView(Button(this).apply {
                        text = "Dukaan ko call karein ($phone)"
                        setOnClickListener { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) }
                    })
                }
            }
        }

        val last = Policy.lastSync(this)
        val status = when {
            synced == false -> "Sync nahi ho saka. Internet check karein."
            last > 0 -> "Aakhri update: " + SimpleDateFormat("dd MMM, hh:mm a", Locale.US).format(Date(last))
            else -> ""
        }
        if (status.isNotEmpty()) root.addView(tv(status, 13f, color = Color.GRAY).apply { setPadding(0, dp(12), 0, 0) })

        root.addView(Button(this).apply {
            text = "Refresh"
            setOnClickListener { refreshInBackground() }
        })

        if (Policy.isTestMode(this) && Policy.isOwner(this)) {
            root.addView(Button(this).apply {
                text = "TEST khatam: app ko phone se hataein"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("Test mode ka phone wapis normal ho jayega aur ye app uninstall ho sakegi. Karein?")
                        .setPositiveButton("Haan") { _, _ -> Policy.release(this@MainActivity); render(null) }
                        .setNegativeButton("Nahi", null)
                        .show()
                }
            })
        }
    }
}
