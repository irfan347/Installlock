"""
Make the enrollment QR for one phone.

pip install qrcode[pil]
python make_qr.py --apk-url https://yourhost/installlock.apk \
  --cert-sha256 AB:CD:... --server https://api.yourhost.com \
  --customer-id C1001 --token SECRET --out c1001.png

--cert-sha256 is the SIGNING CERTIFICATE fingerprint:
  apksigner verify --print-certs installlock.apk
"""
import argparse, base64, binascii, json
import qrcode

ap = argparse.ArgumentParser()
ap.add_argument("--apk-url", required=True)
ap.add_argument("--cert-sha256", required=True)
ap.add_argument("--server", required=True)
ap.add_argument("--customer-id", required=True)
ap.add_argument("--token", required=True)
ap.add_argument("--wifi-ssid")
ap.add_argument("--wifi-pass")
ap.add_argument("--out", default="enroll.png")
a = ap.parse_args()

checksum = base64.urlsafe_b64encode(
    binascii.unhexlify(a.cert_sha256.replace(":", ""))
).decode().rstrip("=")

p = {
    "android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME":
        "com.example.installlock/.AdminReceiver",
    "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION": a.apk_url,
    "android.app.extra.PROVISIONING_DEVICE_ADMIN_SIGNATURE_CHECKSUM": checksum,
    "android.app.extra.PROVISIONING_SKIP_ENCRYPTION": True,
    "android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED": True,
    "android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE": {
        "server": a.server, "customer_id": a.customer_id, "token": a.token,
    },
}
if a.wifi_ssid:
    p["android.app.extra.PROVISIONING_WIFI_SSID"] = a.wifi_ssid
    p["android.app.extra.PROVISIONING_WIFI_PASSWORD"] = a.wifi_pass or ""
    p["android.app.extra.PROVISIONING_WIFI_SECURITY_TYPE"] = "WPA" if a.wifi_pass else "NONE"

qrcode.make(json.dumps(p, separators=(",", ":"))).save(a.out)
print("saved", a.out)
