'use strict';
// Create the initial admin (the owner). Run: node src/seed.js
const { db } = require('./db');
const { hashPassword } = require('./auth');

const phone = process.env.ADMIN_PHONE || '03000000000';
const pass = process.env.ADMIN_PASSWORD || 'admin123';
const name = process.env.ADMIN_NAME || 'Owner';

const existing = db.prepare("SELECT id FROM users WHERE role='admin'").get();
if (existing) {
  console.log('Admin already exists (id=' + existing.id + '). Skipping.');
} else {
  const info = db.prepare("INSERT INTO users (role, name, phone, password, status) VALUES ('admin',?,?,?, 'active')")
    .run(name, phone, hashPassword(pass));
  console.log('Admin created: id=' + info.lastInsertRowid + ', phone=' + phone + ', password=' + pass);
  console.log('>> Change ADMIN_PASSWORD in production.');
}
