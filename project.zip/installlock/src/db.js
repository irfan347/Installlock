'use strict';
// Zero-dependency SQLite layer using Node's built-in node:sqlite (Node 22+).
const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'installlock.db');

const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  role         TEXT NOT NULL CHECK(role IN ('admin','agent')),
  name         TEXT NOT NULL,
  shop_name    TEXT,
  phone        TEXT UNIQUE NOT NULL,
  password     TEXT NOT NULL,           -- scrypt hash
  status       TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','suspended')),
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS customers (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id     INTEGER NOT NULL REFERENCES users(id),
  name         TEXT NOT NULL,
  phone        TEXT NOT NULL,
  cnic         TEXT,                     -- CNIC number
  selfie_path  TEXT,                     -- stored image file
  cnic_path    TEXT,                     -- stored image file
  product      TEXT,                     -- what was sold (e.g. phone model)
  total_price  REAL NOT NULL DEFAULT 0,
  down_payment REAL NOT NULL DEFAULT 0,
  months       INTEGER NOT NULL DEFAULT 0,
  status       TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','rejected','completed')),
  reject_reason TEXT,
  device_locked INTEGER NOT NULL DEFAULT 0,  -- 0/1, controlled after missed payment
  device_id    TEXT,                     -- registered lock-app device identifier
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS installments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id  INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  seq          INTEGER NOT NULL,         -- 1..months
  amount       REAL NOT NULL,
  due_date     TEXT NOT NULL,            -- YYYY-MM-DD
  paid         INTEGER NOT NULL DEFAULT 0,
  paid_at      TEXT,
  method       TEXT,                     -- jazzcash / easypaisa / cash
  txn_ref      TEXT
);

CREATE INDEX IF NOT EXISTS idx_customers_agent ON customers(agent_id);
CREATE INDEX IF NOT EXISTS idx_inst_customer ON installments(customer_id);
CREATE INDEX IF NOT EXISTS idx_inst_due ON installments(due_date, paid);
`);

module.exports = { db, DB_PATH, DATA_DIR };
