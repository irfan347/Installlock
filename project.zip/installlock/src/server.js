'use strict';
// Zero-dependency HTTP server for InstallLock backend + dashboard.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { db, DATA_DIR } = require('./db');
const { hashPassword, verifyPassword, signToken, verifyToken } = require('./auth');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ---------- tiny helpers ----------
function send(res, status, body, headers = {}) {
  const payload = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...headers });
  res.end(payload);
}
function readBody(req, limit = 12 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('payload too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(new Error('invalid JSON')); }
    });
    req.on('error', reject);
  });
}
function today() { return new Date().toISOString().slice(0, 10); }
function addMonths(dateStr, n) {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCMonth(d.getUTCMonth() + n);
  return d.toISOString().slice(0, 10);
}
function saveImage(dataUrl, prefix) {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const m = dataUrl.match(/^data:(image\/(png|jpe?g|webp));base64,(.+)$/);
  if (!m) return null;
  const ext = m[2] === 'jpeg' ? 'jpg' : m[2];
  const name = `${prefix}_${Date.now()}_${crypto.randomBytes(4).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, name), Buffer.from(m[3], 'base64'));
  return name;
}

// ---------- auth middleware ----------
function authUser(req) {
  const h = req.headers['authorization'] || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return null;
  const payload = verifyToken(token);
  if (!payload) return null;
  const user = db.prepare('SELECT id, role, name, shop_name, phone, status FROM users WHERE id = ?').get(payload.uid);
  if (!user || user.status !== 'active') return null;
  return user;
}

// ---------- domain logic ----------
function generateSchedule(customer) {
  const principal = Math.max(0, customer.total_price - customer.down_payment);
  const months = customer.months;
  if (months <= 0) return;
  const base = Math.floor((principal / months) * 100) / 100;
  let allocated = 0;
  const stmt = db.prepare('INSERT INTO installments (customer_id, seq, amount, due_date) VALUES (?,?,?,?)');
  for (let i = 1; i <= months; i++) {
    let amt = base;
    if (i === months) amt = Math.round((principal - allocated) * 100) / 100; // last catches rounding
    allocated += base;
    stmt.run(customer.id, i, amt, addMonths(today(), i));
  }
}

// A customer SHOULD be locked if any installment is overdue and unpaid.
function overdueCount(customerId) {
  return db.prepare(
    "SELECT COUNT(*) c FROM installments WHERE customer_id = ? AND paid = 0 AND due_date < ?"
  ).get(customerId, today()).c;
}
function refreshLockState(customerId) {
  const c = db.prepare('SELECT status FROM customers WHERE id = ?').get(customerId);
  if (!c) return;
  const locked = c.status === 'active' && overdueCount(customerId) > 0 ? 1 : 0;
  db.prepare('UPDATE customers SET device_locked = ? WHERE id = ?').run(locked, customerId);
}

function customerView(c) {
  const inst = db.prepare('SELECT * FROM installments WHERE customer_id = ? ORDER BY seq').all(c.id);
  const paid = inst.filter(i => i.paid).reduce((s, i) => s + i.amount, 0);
  const total = inst.reduce((s, i) => s + i.amount, 0);
  const nextDue = inst.find(i => !i.paid) || null;
  return {
    ...c,
    selfie_url: c.selfie_path ? `/api/files/${c.selfie_path}` : null,
    cnic_url: c.cnic_path ? `/api/files/${c.cnic_path}` : null,
    installments: inst,
    summary: {
      total_financed: Math.round(total * 100) / 100,
      paid: Math.round(paid * 100) / 100,
      remaining: Math.round((total - paid) * 100) / 100,
      overdue: overdueCount(c.id),
      next_due: nextDue ? { seq: nextDue.seq, amount: nextDue.amount, due_date: nextDue.due_date } : null,
    },
  };
}

// ---------- routes ----------
const routes = [];
function route(method, pattern, handler) {
  const keys = [];
  const rx = new RegExp('^' + pattern.replace(/:[^/]+/g, (m) => { keys.push(m.slice(1)); return '([^/]+)'; }) + '$');
  routes.push({ method, rx, keys, handler });
}

// --- Auth ---
route('POST', '/api/auth/register-agent', async (req, res) => {
  const b = await readBody(req);
  if (!b.name || !b.phone || !b.password) return send(res, 400, { error: 'name, phone, password required' });
  const exists = db.prepare('SELECT id FROM users WHERE phone = ?').get(b.phone);
  if (exists) return send(res, 409, { error: 'phone already registered' });
  const info = db.prepare(
    "INSERT INTO users (role, name, shop_name, phone, password, status) VALUES ('agent',?,?,?,?,'pending')"
  ).run(b.name, b.shop_name || null, b.phone, hashPassword(b.password));
  send(res, 201, { id: info.lastInsertRowid, status: 'pending', message: 'Account created. Waiting for admin approval.' });
});

route('POST', '/api/auth/login', async (req, res) => {
  const b = await readBody(req);
  const u = db.prepare('SELECT * FROM users WHERE phone = ?').get(b.phone || '');
  if (!u || !verifyPassword(b.password || '', u.password)) return send(res, 401, { error: 'invalid phone or password' });
  if (u.status === 'pending') return send(res, 403, { error: 'account pending admin approval' });
  if (u.status === 'suspended') return send(res, 403, { error: 'account suspended' });
  const token = signToken({ uid: u.id, role: u.role });
  send(res, 200, { token, user: { id: u.id, role: u.role, name: u.name, shop_name: u.shop_name, phone: u.phone } });
});

route('GET', '/api/me', async (req, res, _p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  send(res, 200, { user });
});

// --- Admin: agents ---
route('GET', '/api/admin/agents', async (req, res, _p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  const rows = db.prepare("SELECT id, name, shop_name, phone, status, created_at FROM users WHERE role='agent' ORDER BY created_at DESC").all();
  send(res, 200, { agents: rows });
});
route('POST', '/api/admin/agents/:id/approve', async (req, res, p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  db.prepare("UPDATE users SET status='active' WHERE id=? AND role='agent'").run(p.id);
  send(res, 200, { ok: true });
});
route('POST', '/api/admin/agents/:id/suspend', async (req, res, p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  db.prepare("UPDATE users SET status='suspended' WHERE id=? AND role='agent'").run(p.id);
  send(res, 200, { ok: true });
});

// --- Admin: enrollment approvals ---
route('GET', '/api/admin/enrollments', async (req, res, _p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  const status = new URL(req.url, 'http://x').searchParams.get('status') || 'pending';
  const rows = db.prepare(`
    SELECT c.*, u.name agent_name, u.shop_name agent_shop
    FROM customers c JOIN users u ON u.id = c.agent_id
    WHERE c.status = ? ORDER BY c.created_at DESC`).all(status);
  send(res, 200, { enrollments: rows.map(customerView) });
});
route('POST', '/api/admin/customers/:id/approve', async (req, res, p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(p.id);
  if (!c) return send(res, 404, { error: 'not found' });
  if (c.status !== 'pending') return send(res, 400, { error: 'already processed' });
  db.prepare("UPDATE customers SET status='active' WHERE id=?").run(c.id);
  const fresh = db.prepare('SELECT * FROM customers WHERE id = ?').get(c.id);
  generateSchedule(fresh);
  refreshLockState(c.id);
  send(res, 200, { ok: true });
});
route('POST', '/api/admin/customers/:id/reject', async (req, res, p, user) => {
  if (!user || user.role !== 'admin') return send(res, 403, { error: 'admin only' });
  const b = await readBody(req);
  db.prepare("UPDATE customers SET status='rejected', reject_reason=? WHERE id=? AND status='pending'").run(b.reason || null, p.id);
  send(res, 200, { ok: true });
});

// --- Agent: customers ---
route('POST', '/api/customers', async (req, res, _p, user) => {
  if (!user || user.role !== 'agent') return send(res, 403, { error: 'agent only' });
  const b = await readBody(req);
  if (!b.name || !b.phone) return send(res, 400, { error: 'name and phone required' });
  if (!b.selfie || !b.cnic_photo) return send(res, 400, { error: 'customer selfie and CNIC photo required for enrollment' });
  const selfie_path = saveImage(b.selfie, 'selfie');
  const cnic_path = saveImage(b.cnic_photo, 'cnic');
  if (!selfie_path || !cnic_path) return send(res, 400, { error: 'images must be base64 data URLs (png/jpg/webp)' });
  const info = db.prepare(`
    INSERT INTO customers (agent_id, name, phone, cnic, selfie_path, cnic_path, product, total_price, down_payment, months, status)
    VALUES (?,?,?,?,?,?,?,?,?,?, 'pending')`).run(
    user.id, b.name, b.phone, b.cnic || null, selfie_path, cnic_path, b.product || null,
    Number(b.total_price) || 0, Number(b.down_payment) || 0, Number(b.months) || 0);
  send(res, 201, { id: info.lastInsertRowid, status: 'pending', message: 'Enrollment submitted for admin approval.' });
});
route('GET', '/api/customers', async (req, res, _p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const rows = user.role === 'admin'
    ? db.prepare('SELECT * FROM customers ORDER BY created_at DESC').all()
    : db.prepare('SELECT * FROM customers WHERE agent_id = ? ORDER BY created_at DESC').all(user.id);
  send(res, 200, { customers: rows.map(customerView) });
});
route('GET', '/api/customers/:id', async (req, res, p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(p.id);
  if (!c) return send(res, 404, { error: 'not found' });
  if (user.role === 'agent' && c.agent_id !== user.id) return send(res, 403, { error: 'forbidden' });
  refreshLockState(c.id);
  send(res, 200, { customer: customerView(db.prepare('SELECT * FROM customers WHERE id = ?').get(c.id)) });
});

// --- Payments / installments ---
route('POST', '/api/installments/:id/pay', async (req, res, p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const b = await readBody(req);
  const inst = db.prepare('SELECT * FROM installments WHERE id = ?').get(p.id);
  if (!inst) return send(res, 404, { error: 'not found' });
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(inst.customer_id);
  if (user.role === 'agent' && c.agent_id !== user.id) return send(res, 403, { error: 'forbidden' });
  if (inst.paid) return send(res, 400, { error: 'already paid' });
  db.prepare("UPDATE installments SET paid=1, paid_at=datetime('now'), method=?, txn_ref=? WHERE id=?")
    .run(b.method || 'cash', b.txn_ref || null, inst.id);
  // complete customer if all paid
  const remaining = db.prepare('SELECT COUNT(*) c FROM installments WHERE customer_id=? AND paid=0').get(inst.customer_id).c;
  if (remaining === 0) db.prepare("UPDATE customers SET status='completed', device_locked=0 WHERE id=?").run(inst.customer_id);
  else refreshLockState(inst.customer_id);
  send(res, 200, { ok: true, remaining });
});

// --- Reminders: installments due within 2 days, unpaid ---
route('GET', '/api/reminders', async (req, res, _p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const t = today();
  const in2 = addMonths; // not used; compute 2 days
  const d = new Date(t + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + 2);
  const limit = d.toISOString().slice(0, 10);
  const base = `
    SELECT i.id, i.seq, i.amount, i.due_date, c.id customer_id, c.name customer_name, c.phone customer_phone, c.agent_id
    FROM installments i JOIN customers c ON c.id = i.customer_id
    WHERE i.paid = 0 AND c.status = 'active' AND i.due_date <= ?`;
  const rows = user.role === 'admin'
    ? db.prepare(base + ' ORDER BY i.due_date').all(limit)
    : db.prepare(base + ' AND c.agent_id = ? ORDER BY i.due_date').all(limit, user.id);
  send(res, 200, { reminders: rows, as_of: t, through: limit });
});

// --- Device lock polling (used by the lock APK) ---
route('POST', '/api/device/register', async (req, res, _p, user) => {
  if (!user) return send(res, 401, { error: 'unauthorized' });
  const b = await readBody(req);
  const c = db.prepare('SELECT * FROM customers WHERE id = ?').get(b.customer_id);
  if (!c) return send(res, 404, { error: 'customer not found' });
  if (user.role === 'agent' && c.agent_id !== user.id) return send(res, 403, { error: 'forbidden' });
  db.prepare('UPDATE customers SET device_id = ? WHERE id = ?').run(b.device_id || null, c.id);
  send(res, 200, { ok: true });
});
// Lock app polls this (device_id acts as shared identifier). Returns whether device should be locked.
route('GET', '/api/device/status', async (req, res) => {
  const device_id = new URL(req.url, 'http://x').searchParams.get('device_id');
  if (!device_id) return send(res, 400, { error: 'device_id required' });
  const c = db.prepare('SELECT * FROM customers WHERE device_id = ?').get(device_id);
  if (!c) return send(res, 404, { error: 'device not registered' });
  refreshLockState(c.id);
  const fresh = db.prepare('SELECT device_locked, status FROM customers WHERE id = ?').get(c.id);
  send(res, 200, {
    locked: !!fresh.device_locked,
    status: fresh.status,
    message: fresh.device_locked
      ? 'Aapki installment due hai. Bara-e-karam ada karein taake phone unlock ho jaye.'
      : 'OK',
  });
});

// ---------- static + files ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' };
function serveStatic(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, { error: 'not found' });
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const pathname = decodeURIComponent(url.pathname);

    // uploaded files (auth-gated)
    if (pathname.startsWith('/api/files/')) {
      const user = authUser(req);
      if (!user) return send(res, 401, { error: 'unauthorized' });
      const name = path.basename(pathname.slice('/api/files/'.length));
      return serveStatic(res, path.join(UPLOAD_DIR, name));
    }

    if (pathname.startsWith('/api/')) {
      const match = routes.find(r => r.method === req.method && r.rx.test(pathname));
      if (!match) return send(res, 404, { error: 'route not found' });
      const m = pathname.match(match.rx);
      const params = {};
      match.keys.forEach((k, i) => { params[k] = m[i + 1]; });
      const needsAuth = !['/api/auth/login', '/api/auth/register-agent', '/api/device/status'].includes(pathname);
      const user = authUser(req);
      if (needsAuth && !user) return send(res, 401, { error: 'unauthorized' });
      return match.handler(req, res, params, user);
    }

    // static dashboard
    let fp = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname.replace(/^\//, ''));
    if (!fp.startsWith(PUBLIC_DIR)) return send(res, 403, { error: 'forbidden' });
    if (!fs.existsSync(fp)) fp = path.join(PUBLIC_DIR, 'index.html'); // SPA fallback
    serveStatic(res, fp);
  } catch (e) {
    send(res, e.message === 'invalid JSON' || e.message === 'payload too large' ? 400 : 500, { error: e.message });
  }
});

server.listen(PORT, () => console.log(`InstallLock backend running on http://localhost:${PORT}`));
module.exports = server;
