# InstallLock — Backend + Shopkeeper Dashboard

Installment / BNPL management system for Pakistan. This is **Part 1**: the backend API and the
web dashboard that shopkeepers (agents) and the owner (admin) use. The customer app and the
consent-based device-lock Android app connect to this same backend later.

Built with **zero npm dependencies** — only Node.js built-ins (`node:http`, `node:sqlite`,
`node:crypto`). Needs **Node.js 22.5+**.

## What it does

- **Admin (owner)** approves shopkeeper accounts before they can log in.
- **Shopkeepers (agents)** register a sale: customer details + **selfie photo + CNIC photo**
  (both required). The sale stays *pending* until the admin approves it.
- On approval, an **installment schedule** is generated automatically
  (financed amount = total − down payment, split across the chosen months).
- **Customers'** paid / remaining amounts are tracked; payments are recorded
  (JazzCash / Easypaisa / cash + transaction reference).
- **Reminders**: lists every installment due within the next 2 days.
- **Device lock**: a customer's device is marked "should be locked" automatically when any
  installment is overdue and unpaid, and unlocks as soon as it's paid. The lock Android app
  polls `/api/device/status`.

## Run locally

```bash
node --experimental-sqlite src/seed.js     # create the admin owner (once)
node --experimental-sqlite src/server.js   # start on http://localhost:3000
# or: npm run seed  &&  npm start
```

Open http://localhost:3000 in a browser.

**Default admin** (change it!): phone `03000000000`, password `admin123`.
Set these before seeding in production:

```bash
ADMIN_PHONE=03XXXXXXXXX ADMIN_PASSWORD='a-strong-password' APP_SECRET='long-random-string' node --experimental-sqlite src/seed.js
```

Always set a real `APP_SECRET` env var in production — it signs the login tokens.

## Environment variables

| Var | Purpose | Default |
|-----|---------|---------|
| `PORT` | HTTP port | `3000` |
| `APP_SECRET` | Signs auth tokens — **must set in production** | `dev-secret-change-me` |
| `DB_PATH` | SQLite file path | `data/installlock.db` |
| `ADMIN_PHONE` / `ADMIN_PASSWORD` / `ADMIN_NAME` | Seed admin | `03000000000` / `admin123` / `Owner` |

## API summary

| Method | Path | Who | Purpose |
|--------|------|-----|---------|
| POST | `/api/auth/register-agent` | public | Shopkeeper signup (pending) |
| POST | `/api/auth/login` | public | Login → token |
| GET  | `/api/me` | auth | Current user |
| GET  | `/api/admin/agents` | admin | List shopkeepers |
| POST | `/api/admin/agents/:id/approve` \| `/suspend` | admin | Activate / suspend shopkeeper |
| GET  | `/api/admin/enrollments?status=pending` | admin | Enrollments awaiting approval (with photos) |
| POST | `/api/admin/customers/:id/approve` \| `/reject` | admin | Approve (generates schedule) / reject |
| POST | `/api/customers` | agent | Create sale (selfie + CNIC required) |
| GET  | `/api/customers` | auth | List customers (own, or all for admin) |
| GET  | `/api/customers/:id` | auth | Customer + installments |
| POST | `/api/installments/:id/pay` | auth | Record a payment |
| GET  | `/api/reminders` | auth | Installments due within 2 days |
| POST | `/api/device/register` | auth | Link a device_id to a customer |
| GET  | `/api/device/status?device_id=…` | lock app | Returns `{locked: true/false}` |

Photos are sent as base64 data URLs and stored under `uploads/`.

## About the device-lock feature (important)

The device lock is modeled on legitimate device financing (like PayJoy, or Google's own
[Android Device Lock Controller](https://source.android.com/docs/core/admin/device-lock)).
For it to stay lawful and fair:

- The customer must **consent in writing** at enrollment and understand the device can be locked
  for non-payment (make it part of the loan agreement they sign).
- The lock app will use Android's **official Device Policy / Device Owner APIs** — nothing hidden
  or disguised.
- A locked device must still allow **emergency calls**, and it unlocks automatically on payment.

The backend only exposes *whether* a device should be locked; the actual locking happens in the
Android app (Part 3), built that way.

## Deploy

Any host that runs Node 22+ works (Render, Railway, Fly.io, a VPS, etc.). Start command:
`node --experimental-sqlite src/server.js`. Persist the `data/` and `uploads/` folders.

## Roadmap

1. ✅ Backend + shopkeeper/admin dashboard (this)
2. ⬜ Customer app (view installments, reminders, JazzCash/Easypaisa payment)
3. ⬜ Lock APK (device-owner app, consent-based) — built via GitHub Actions
4. ⬜ JazzCash / Easypaisa payment gateway integration
